import java.awt.Color;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.Timer;
import javax.swing.UIManager;

/**
 * ...
 */
public class Cutscenes extends javax.swing.JFrame {
    static String diretorio;
    static String texto;
    static int dialogoCont;
    static int index = 0;
    static Timer timer;

    /**
     * Creates new form Cutscenes
     */
    public Cutscenes() {
        super("CodeQuest");
        initComponents();
        this.setLocationRelativeTo(null);
        TelaInicial.scaleImageButton(TelaInicial.interfaceDire + "\\seta.png", seta);
        TelaInicial.scaleImage(diretorio, Cutscene);
        TelaInicial.scaleImage(TelaInicial.backgroundDire + "\\fundo.jpeg", Dialogo);
        historia.setOpaque(false);
        UIManager.put("TextArea.background", new Color(0, 0, 0, 0));
        dialogoCont = 1;
        setupTimer(texto, historia);
    }

    public void setupTimer(String text, JTextArea caixa) {
        timer = new Timer(25, (e) -> {
            if (index < texto.length()) {
                caixa.append(String.valueOf(text.charAt(index)));
                index++;
            } else {
                timer.stop();
            }
        });
        timer.start();
    }
    public void proximoDialogo(String text,JTextArea dialogo) {
        if (timer.isRunning()) {
            timer.stop();
        }
        historia.setText("");
        index = 0;
        setupTimer(text, dialogo);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        seta = new javax.swing.JButton();
        historia = new javax.swing.JTextArea();
        Dialogo = new javax.swing.JLabel();
        Cutscene = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(1450, 760));
        setMinimumSize(new java.awt.Dimension(1450, 760));
        setPreferredSize(new java.awt.Dimension(1450, 760));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        seta.setBorder(null);
        seta.setBorderPainted(false);
        seta.setContentAreaFilled(false);
        seta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                setaActionPerformed(evt);
            }
        });
        getContentPane().add(seta, new org.netbeans.lib.awtextra.AbsoluteConstraints(1320, 640, 90, 70));

        historia.setEditable(false);
        historia.setBackground(new java.awt.Color(0, 0, 0));
        historia.setColumns(20);
        historia.setFont(new java.awt.Font("Arial", 0, 32)); // NOI18N
        historia.setForeground(new java.awt.Color(255, 255, 255));
        historia.setRows(5);
        historia.setBorder(null);
        getContentPane().add(historia, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 520, 1370, 180));

        Dialogo.setText("jLabel1");
        getContentPane().add(Dialogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, 510, 1470, 210));

        Cutscene.setText("jLabel1");
        getContentPane().add(Cutscene, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 1450, 730));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void setaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_setaActionPerformed
        switch (Fases.faseCont) {
        case 1:
            switch (dialogoCont) {
                case 1:
                    Audios.stopBackgroundMusic();
                    Audios.playSound(TelaInicial.sonsDire +"\\explosao.wav");
                    texto = "Enquanto você observava a natureza pacífica ao seu redor na cabana isolada, uma explosão \n" + "mágica vinda do castelo ecoou. Seus olhos perceberam o perigo e seu coração de guerreiro(a) \n" + "se inflamou novamente. Sem hesitar, você se levantou, agarrou sua espada e decidiu \n" +"responder ao chamado de ajuda.";
                    TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\explosaoCutscene.png", Cutscene);
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 2:
                    Audios.stopBackgroundMusic();
                    Audios.playBackgroundMusic(TelaInicial.sonsDire +"\\somFloresta.wav");
                    texto = "Ao entrar na floresta, ouve um barulho vindo dos arbustos. Pronto para o combate, você segura\n" + "sua espada com firmeza. Um brilho alaranjado chama sua atenção...";
                    TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\florestaCutscene.png", Cutscene);
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 3:
                    Audios.stopBackgroundMusic();
                    Audios.playSound(TelaInicial.sonsDire +"\\JackOBirdSound.wav");
                    texto = "!!!";
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 4:
                    Audios.stopBackgroundMusic();
                    Audios.playBackgroundMusic(TelaInicial.musicaDire +"\\Pesadelo_Verde.wav");
                    TelaQuiz perguntas = new TelaQuiz();
                    perguntas.setVisible(true);
                    this.dispose();
                    break;
            }
            break;
        case 2:
            switch (dialogoCont) {
                case 1:
                    texto = "Seguindo em frente na floresta, você ouve sussurros e barulhos no topo das árvores. Você\n" + "olha para cima atentamente...";
                    TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\notivagaCutscene.png", Cutscene);
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 2:
                    Audios.stopBackgroundMusic();
                    Audios.playSound(TelaInicial.sonsDire + "\\NotivagaSound.wav");
                    texto = "!!!";
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 3:
                    Audios.stopBackgroundMusic();
                    Audios.playBackgroundMusic(TelaInicial.musicaDire +"\\Pesadelo_Verde.wav");
                    TelaQuiz perguntas = new TelaQuiz();
                    perguntas.setVisible(true);
                    this.dispose();
                    break;
            }
            break;
        case 3:
            switch (dialogoCont){
                case 1:
                    Audios.stopBackgroundMusic();
                    Audios.playBackgroundMusic(TelaInicial.sonsDire + "\\rioSons.wav");
                    texto = "Você encontra uma ponte estreita sobre um lago. Enquanto atravessa, ouve um barulho\n" +"misterioso vindo da água, despertando sua curiosidade. Algo grande se aproxima...";
                    TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\vurpuraCutscene.png", Cutscene);
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 2:
                    Audios.stopBackgroundMusic();
                    Audios.playSound(TelaInicial.sonsDire +"\\MetaVurpuraSound.wav");
                    texto = "!!!";
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 3:
                    Audios.stopBackgroundMusic();
                    Audios.playBackgroundMusic(TelaInicial.musicaDire +"\\vurpuraSong.wav");
                    TelaQuiz perguntas = new TelaQuiz();
                    perguntas.setVisible(true);
                    this.dispose();
                    break;
            }
            break;
        case 4:
            switch (dialogoCont){
                case 1:
                    texto = "Você percebe que seu último golpe acabou arrancando uma das presas da serpente, que estava \n" + "agora no chão. Você decide extrair o veneno para caso ele lhe seja útil no futuro.";
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 2:
                    Audios.stopBackgroundMusic();
                    Audios.playBackgroundMusic(TelaInicial.sonsDire +"\\naturezaSons.wav");
                    texto = "Você se aproxima da entrada da caverna, curioso sobre um possível caminho mais rápido para \n" +"o reino. Com cautela, você adentra o local, determinado a descobrir o que há nesse labirinto \n" +"subterrâneo. ";
                    TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\Floresta-Caverna.png", Cutscene);
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 3:
                    Audios.stopBackgroundMusic();
                    Audios.playBackgroundMusic(TelaInicial.sonsDire +"\\somCaverna.wav");
                    texto = "Ao adentrar a caverna, você encontra um ninho de aranha gigante, com teias por todos os lados. \n" + "Parece que há algo se movendo furtivamente no teto...";
                    TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\aracnaxCutscene.png", Cutscene);
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 4:
                    Audios.stopBackgroundMusic();
                    Audios.playSound(TelaInicial.sonsDire + "\\AracnaXSound.wav");
                    texto = "!!!";
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 5:
                    Audios.stopBackgroundMusic();
                    Audios.playBackgroundMusic(TelaInicial.musicaDire +"\\CavernaMusica.wav");
                    TelaQuiz perguntas = new TelaQuiz();
                    perguntas.setVisible(true);
                    this.dispose();
                    break;
            }
            break;
            case 5:
            switch (dialogoCont){
                case 1:
                    texto = "Você avança mais profundamente na caverna, chegando a uma região brilhante com cristais \n" + "reluzentes. Uma sensação de ser observado o acompanha... ";
                    TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\cavernaCutscene.png", Cutscene);
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 2:
                    Audios.stopBackgroundMusic();
                    Audios.playSound(TelaInicial.sonsDire +"\\PanteraLotusSound.wav");
                    texto = "!!!";
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 3:
                    Audios.stopBackgroundMusic();
                    Audios.playBackgroundMusic(TelaInicial.musicaDire +"\\CavernaMusica.wav");
                    TelaQuiz perguntas = new TelaQuiz();
                    perguntas.setVisible(true);
                    this.dispose();
                    break;
            }
            break;
            case 6:
            switch (dialogoCont){
                case 1:
                    texto = "Ao chegar ao fim da caverna, você percebe alguém se aproximando. Uma sensação de intriga \n" + "toma conta de você, enquanto os passos se aproximam cada vez mais...";
                    TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\reaperCutscene.png", Cutscene);
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 2:
                    Audios.stopBackgroundMusic();
                    Audios.playSound(TelaInicial.sonsDire +"\\BloodReaperSound.wav");
                    texto = "!!!";
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 3:
                    Audios.stopBackgroundMusic();
                    Audios.playBackgroundMusic(TelaInicial.musicaDire +"\\Eco_Perpetuo.wav");
                    TelaQuiz perguntas = new TelaQuiz();
                    perguntas.setVisible(true);
                    this.dispose();
                    break;
            }
            break;
            case 7:
            switch (dialogoCont){
                case 1:
                    texto = "Em meio ao desabamento, você encontra um livro misterioso que pertencia ao cultista.\n" +"Intrigado, você decide leva-lo com sigo.";
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 2:
                    Audios.stopBackgroundMusic();
                    Audios.playBackgroundMusic(TelaInicial.sonsDire +"\\ventoSons.wav");
                    texto = "Ao chegar às portas do castelo, você se depara com uma visão desoladora. O castelo está \n" +"deserto e em ruínas, o reino completamente destruído. O silêncio e a devastação lembram \n" +"você da importância de sua missão.";
                    TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\Caverna-Castelo.jpg", Cutscene);
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 3:
                    Audios.stopBackgroundMusic();
                    Audios.playBackgroundMusic(TelaInicial.sonsDire +"\\somCastelo.wav");
                    texto = "Ao entrar no castelo, você se depara com uma sala ampla cheia de quadros e pinturas. \n" +"Uma sensação arrepiante toma conta de você ao sentir que há algo sobrenatural em um \n" + "dos quadros. Olhos te observando, uma presença fantasmagórica no ar... tem algo atrás \n" + "de você...";
                    TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\visageCutscene.png", Cutscene);
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 4:
                    Audios.stopBackgroundMusic();
                    Audios.playSound(TelaInicial.sonsDire + "\\VisageSound.wav");
                    texto = "!!!";
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 5:
                    Audios.stopBackgroundMusic();
                    Audios.playBackgroundMusic(TelaInicial.musicaDire +"\\Torre_Dos_Sussurros.wav");
                    TelaQuiz perguntas = new TelaQuiz();
                    perguntas.setVisible(true);
                    this.dispose();
                    break;
        }
            break;
            case 8:
            switch (dialogoCont){
                case 1:
                    texto = "Avançando ainda mais no castelo, você nota gradualmente as cores desaparecendo tanto do \n" +"ambiente quanto de si mesmo. Uma sensação de melancolia e desvanecimento toma conta \n" +"de você. E então, percebe uma figura alta te observando de perto...";
                    TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\casteloCutsceneB.png", Cutscene);
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 2:
                    Audios.stopBackgroundMusic();
                    Audios.playSound(TelaInicial.sonsDire +"\\OblivionVoice.wav");
                    texto = "!!!";
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 3:
                    Audios.stopBackgroundMusic();
                    Audios.playBackgroundMusic(TelaInicial.musicaDire +"\\Torre_Dos_Sussurros.wav");
                    TelaQuiz perguntas = new TelaQuiz();
                    perguntas.setVisible(true);
                    this.dispose();
                    break;
            }
            break;
            case 9:
            switch (dialogoCont){
                case 1:
                    texto = "Ao prosseguir em sua jornada pelo castelo, você descobre uma passagem secreta que promete \n" +"ser um atalho para a sala do trono. No entanto, ao passar por ela, seu olhar é atraído por um \n" +"vaso misterioso, emanando uma aura sombria. Uma sensação de inquietação toma conta de \n" +"você, pressentindo que algo sinistro está prestes a emergir dali...";
                    TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\rupturaCutscene.png", Cutscene);
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 2:
                    Audios.stopBackgroundMusic();
                    Audios.playSound(TelaInicial.sonsDire +"\\RupturaSound.wav");
                    texto = "!!!";
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 3:
                    Audios.stopBackgroundMusic();
                    Audios.playBackgroundMusic(TelaInicial.musicaDire +"\\rupturaSong.wav");
                    TelaQuiz perguntas = new TelaQuiz();
                    perguntas.setVisible(true);
                    this.dispose();
                    break;
            }
            break;
            case 10:
            switch (dialogoCont){
                case 1:
                    texto = "Após investigar o vaso, você encontra um antigo pergaminho, porém ele está em um língua\n" + "desconhecida, talvez o livro possa ser de alguma ajuda?";
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 2:
                    texto = "Com habilidade e conhecimento, você usa o livro para decifrar o texto antigo no pergaminho. \n" +"As palavras ganham vida sob seus olhos, revelando segredos ancestrais. Em seguida, com \n" +"destreza, você utiliza o pergaminho e o veneno especial para realizar um encantamento\n" +"poderoso em sua espada. A lâmina brilha com uma energia mística, agora você está \n" +"realmente pronto.";
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 3:
                    Audios.stopBackgroundMusic();
                    Audios.playBackgroundMusic(TelaInicial.sonsDire +"\\medoM.wav");
                    texto = "Ao adentrar a sala do trono, você se depara com um panorama desolador. O ambiente está em\n" +"ruínas, revelando um céu aberto acima. No horizonte distante, seus olhos captam uma figura \n" +"misteriosa flutuando, envolta em uma aura intimidadora. Seu coração dispara, revelando que \n" + "um desafio ainda maior lhe aguarda... ";
                    TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\finalCutscene.png", Cutscene);
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 4:
                    Audios.stopBackgroundMusic();
                    Audios.playSound(TelaInicial.sonsDire + "\\vilaoSound.wav");
                    texto = "!!!";
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 5:
                    Audios.stopBackgroundMusic();
                    Audios.playBackgroundMusic(TelaInicial.musicaDire +"\\O_Ultimo_Remanescente.wav");
                    TelaQuiz perguntas = new TelaQuiz();
                    perguntas.setVisible(true);
                    this.dispose();
                    break;
        }
            break;
            case 11:
            switch (dialogoCont){
                case 1:
                    texto = "Exausto, você retira sua máscara, permitindo-se admirar o nascer do sol e descansar por um \n" +"momento. Sua missão chega ao fim, deixando um legado de bravura e proteção ao reino. ";
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 2:
                    texto = "Fim.";
                    proximoDialogo(texto, historia);
                    dialogoCont++;
                    break;
                case 3:
                    Audios.stopBackgroundMusic();
                    Audios.playBackgroundMusic(TelaInicial.musicaDire +"\\creditosSong.wav");
                    Ranking fim = new Ranking();
                    fim.setVisible(true);
                    this.dispose();
                    break;
            }
            break;
        }
        Fases.iniciarTimer();
    }//GEN-LAST:event_setaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cutscenes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cutscenes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cutscenes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cutscenes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cutscenes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Cutscene;
    private javax.swing.JLabel Dialogo;
    public javax.swing.JTextArea historia;
    private javax.swing.JButton seta;
    // End of variables declaration//GEN-END:variables
}
