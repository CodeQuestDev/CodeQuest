import java.awt.Color;
import java.awt.Image;
import javax.swing.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author user
 */
public class TelaQuiz extends javax.swing.JFrame{
    /**
     * Creates new form TelaQuiz
     */
    public TelaQuiz() {
        super("CodeQuest");
        initComponents();
        this.setLocationRelativeTo(null);
        vidaProtag.setText(Integer.toString(Player.vidaJogo));
        vidaInimigo.setText(Integer.toString(Inimigos.vidaInimigo));
        vidaProtag.setBackground(new java.awt.Color(0,0,0,1));
        vidaProtag.setBackground(new java.awt.Color(0,0,0,1));
        TelaInicial.scaleImage(TelaInicial.personagemDire +"\\protagonista.png", protagonista);
        TelaInicial.scaleImage(TelaInicial.backgroundDire + "\\fundo.jpeg", fundo);
        TelaInicial.scaleImage(TelaInicial.interfaceDire + "\\coracao.png", Coracao);
        TelaInicial.scaleImage(TelaInicial.interfaceDire +"\\coracao.png", Coracao2);
        nomeProtag.setText(Player.nome );
        questao.setText(Fases.questao );
        a.setOpaque(false);
        UIManager.put("TextArea.background", new Color(0, 0, 0, 0));
        b.setOpaque(false);
        UIManager.put("TextArea.background", new Color(0, 0, 0, 0));
        c.setOpaque(false);
        UIManager.put("TextArea.background", new Color(0, 0, 0, 0));
        d.setOpaque(false);
        UIManager.put("TextArea.background", new Color(0, 0, 0, 0));
        a.setText(Fases.alternativa1 );
        b.setText(Fases.alternativa2 );
        c.setText(Fases.alternativa3 );
        d.setText(Fases.alternativa4 );
        alternativaA.setOpaque(false);
        alternativaB.setOpaque(false);
        alternativaC.setOpaque(false);
        alternativaD.setOpaque(false);
        switch (Fases.faseCont){
            case 1:
                nomeTerrorBird.setText(Fases.nomeInimigo);
                TelaInicial.scaleImage(Fases.inimigo, JackOBird);
                TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\fundoFloresta.jpg", fundoProtagonista);
                break;
            case 2:
                nomeDruida.setText(Fases.nomeInimigo);
                TelaInicial.scaleImage(Fases.inimigo, Notivaga);
                TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\fundoProtag.png", fundoProtagonista);
                break;
            case 3:
                nomeCobra.setText(Fases.nomeInimigo);
                TelaInicial.scaleImage(Fases.inimigo, MetaVurpura);
                TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\fundoFloresta2.png", fundoProtagonista);
                break;
            case 4:
                nomeAranha.setText(Fases.nomeInimigo);
                TelaInicial.scaleImage(Fases.inimigo, AracnaX);
                TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\fundoCaverna.jpg", fundoProtagonista);
                break;
            case 5:
                nomePantera.setText(Fases.nomeInimigo);
                TelaInicial.scaleImage(Fases.inimigo, PanteraLotus);
                ImageIcon gifIcon = new ImageIcon(TelaInicial.backgroundDire + "\\fundoCaverna.gif");
                Image gifImage = gifIcon.getImage();
                int width = fundoProtagonista.getWidth();
                int height = fundoProtagonista.getHeight();
                Image resizedImage = gifImage.getScaledInstance(width, height, Image.SCALE_DEFAULT);
                ImageIcon resizedIcon = new ImageIcon(resizedImage);
                fundoProtagonista.setIcon(resizedIcon);
                break;
            case 6:
                nomeCultista.setText(Fases.nomeInimigo);
                TelaInicial.scaleImage(Fases.inimigo, BloodReaper);
                TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\fundoCaverna.jpeg", fundoProtagonista);
                break;
            case 7:
                nomeFantasma.setText(Fases.nomeInimigo);
                TelaInicial.scaleImage(Fases.inimigo, Visage);
                TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\fundoCastelo.jpg", fundoProtagonista);
                break;
            case 8:
                nomeEntidade.setText(Fases.nomeInimigo);
                TelaInicial.scaleImage(Fases.inimigo, Oblivion);
                TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\fundoOblivion.png", fundoProtagonista);
                TelaInicial.scaleImage(TelaInicial.personagemDire +"\\protagonistaCinza.png", protagonista);
                break;
            case 9:
                nomeEspirito.setText(Fases.nomeInimigo);
                TelaInicial.scaleImage(Fases.inimigo, Ruptura);
                ImageIcon gifIcon2 = new ImageIcon(TelaInicial.backgroundDire + "\\fundoCastelo.gif");
                Image gifImage2 = gifIcon2.getImage();
                int width2 = fundoProtagonista.getWidth();
                int height2 = fundoProtagonista.getHeight();
                Image resizedImage2 = gifImage2.getScaledInstance(width2, height2, Image.SCALE_DEFAULT);
                ImageIcon resizedIcon2 = new ImageIcon(resizedImage2);
                fundoProtagonista.setIcon(resizedIcon2);
                break;
            case 10:
                nomeVilao.setText(Fases.nomeInimigo);
                TelaInicial.scaleImage(Fases.inimigo, Magnata);
                TelaInicial.scaleImage(TelaInicial.backgroundDire +  "\\fundoFinal.jpg", fundoProtagonista);
                break;
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        a = new javax.swing.JTextArea();
        b = new javax.swing.JTextArea();
        d = new javax.swing.JTextArea();
        c = new javax.swing.JTextArea();
        nomeProtag = new javax.swing.JLabel();
        alternativaB = new javax.swing.JRadioButton();
        alternativaC = new javax.swing.JRadioButton();
        alternativaA = new javax.swing.JRadioButton();
        alternativaD = new javax.swing.JRadioButton();
        questao = new javax.swing.JLabel();
        fundo = new javax.swing.JLabel();
        nomeVilao = new javax.swing.JLabel();
        Magnata = new javax.swing.JLabel();
        nomeEspirito = new javax.swing.JLabel();
        Ruptura = new javax.swing.JLabel();
        nomeEntidade = new javax.swing.JLabel();
        Oblivion = new javax.swing.JLabel();
        nomeFantasma = new javax.swing.JLabel();
        Visage = new javax.swing.JLabel();
        nomeCultista = new javax.swing.JLabel();
        BloodReaper = new javax.swing.JLabel();
        nomePantera = new javax.swing.JLabel();
        PanteraLotus = new javax.swing.JLabel();
        nomeAranha = new javax.swing.JLabel();
        AracnaX = new javax.swing.JLabel();
        nomeCobra = new javax.swing.JLabel();
        MetaVurpura = new javax.swing.JLabel();
        nomeDruida = new javax.swing.JLabel();
        Notivaga = new javax.swing.JLabel();
        nomeTerrorBird = new javax.swing.JLabel();
        JackOBird = new javax.swing.JLabel();
        Coracao2 = new javax.swing.JLabel();
        vidaProtag = new javax.swing.JLabel();
        vidaInimigo = new javax.swing.JLabel();
        protagonista = new javax.swing.JLabel();
        Coracao = new javax.swing.JLabel();
        fundoProtagonista = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(1450, 760));
        setMinimumSize(new java.awt.Dimension(1450, 760));
        setModalExclusionType(java.awt.Dialog.ModalExclusionType.APPLICATION_EXCLUDE);
        setPreferredSize(new java.awt.Dimension(1450, 760));
        setResizable(false);
        setSize(new java.awt.Dimension(1450, 760));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        a.setEditable(false);
        a.setColumns(20);
        a.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        a.setForeground(new java.awt.Color(255, 255, 255));
        a.setRows(5);
        a.setBorder(null);
        getContentPane().add(a, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 220, 690, 80));

        b.setEditable(false);
        b.setColumns(20);
        b.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        b.setForeground(new java.awt.Color(255, 255, 255));
        b.setRows(5);
        b.setBorder(null);
        getContentPane().add(b, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 310, 700, 80));

        d.setEditable(false);
        d.setColumns(20);
        d.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        d.setForeground(new java.awt.Color(255, 255, 255));
        d.setRows(5);
        d.setText("\n");
        d.setBorder(null);
        getContentPane().add(d, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 490, 710, 80));

        c.setEditable(false);
        c.setColumns(20);
        c.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        c.setForeground(new java.awt.Color(255, 255, 255));
        c.setRows(5);
        c.setBorder(null);
        getContentPane().add(c, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 400, 690, 80));

        nomeProtag.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        nomeProtag.setForeground(new java.awt.Color(255, 255, 255));
        nomeProtag.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nomeProtag.setText("Jack-O-Bird");
        getContentPane().add(nomeProtag, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, 320, 50));

        buttonGroup1.add(alternativaB);
        alternativaB.setBorder(null);
        alternativaB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alternativaBActionPerformed(evt);
            }
        });
        getContentPane().add(alternativaB, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 290, 20, 72));

        buttonGroup1.add(alternativaC);
        alternativaC.setBorder(null);
        alternativaC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alternativaCActionPerformed(evt);
            }
        });
        getContentPane().add(alternativaC, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 380, 20, 80));

        buttonGroup1.add(alternativaA);
        alternativaA.setBorder(null);
        alternativaA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alternativaAActionPerformed(evt);
            }
        });
        getContentPane().add(alternativaA, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 200, 20, 80));

        buttonGroup1.add(alternativaD);
        alternativaD.setBorder(null);
        alternativaD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alternativaDActionPerformed(evt);
            }
        });
        getContentPane().add(alternativaD, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 470, 20, 80));

        questao.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        questao.setForeground(new java.awt.Color(255, 255, 255));
        questao.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(questao, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 40, 710, 91));

        fundo.setText("jLabel3");
        getContentPane().add(fundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 0, 780, 720));

        nomeVilao.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        nomeVilao.setForeground(new java.awt.Color(255, 255, 255));
        nomeVilao.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(nomeVilao, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 110, 320, 50));
        getContentPane().add(Magnata, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 110, 650, 700));

        nomeEspirito.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        nomeEspirito.setForeground(new java.awt.Color(255, 255, 255));
        nomeEspirito.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(nomeEspirito, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 190, 320, 50));
        getContentPane().add(Ruptura, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 180, 550, 550));

        nomeEntidade.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        nomeEntidade.setForeground(new java.awt.Color(255, 255, 255));
        nomeEntidade.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(nomeEntidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 80, 320, 50));
        getContentPane().add(Oblivion, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 120, 500, 630));

        nomeFantasma.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        nomeFantasma.setForeground(new java.awt.Color(255, 255, 255));
        nomeFantasma.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(nomeFantasma, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 180, 320, 50));
        getContentPane().add(Visage, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 220, 440, 530));

        nomeCultista.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        nomeCultista.setForeground(new java.awt.Color(255, 255, 255));
        nomeCultista.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(nomeCultista, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 190, 320, 50));

        BloodReaper.setText("jLabel1");
        getContentPane().add(BloodReaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 230, 480, 520));

        nomePantera.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        nomePantera.setForeground(new java.awt.Color(255, 255, 255));
        nomePantera.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(nomePantera, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 340, 320, 50));
        getContentPane().add(PanteraLotus, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 200, 820, 670));

        nomeAranha.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        nomeAranha.setForeground(new java.awt.Color(255, 255, 255));
        nomeAranha.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(nomeAranha, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 270, 320, 50));

        AracnaX.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        AracnaX.setFocusable(false);
        AracnaX.setRequestFocusEnabled(false);
        getContentPane().add(AracnaX, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 290, 590, 500));

        nomeCobra.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        nomeCobra.setForeground(new java.awt.Color(255, 255, 255));
        nomeCobra.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(nomeCobra, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 110, 340, 50));
        getContentPane().add(MetaVurpura, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 90, 1000, 710));

        nomeDruida.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        nomeDruida.setForeground(new java.awt.Color(255, 255, 255));
        nomeDruida.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(nomeDruida, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 240, 320, 50));
        getContentPane().add(Notivaga, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 100, 770, 800));

        nomeTerrorBird.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        nomeTerrorBird.setForeground(new java.awt.Color(255, 255, 255));
        nomeTerrorBird.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(nomeTerrorBird, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 160, 320, 50));
        getContentPane().add(JackOBird, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 120, 780, 680));

        Coracao2.setText("jLabel1");
        getContentPane().add(Coracao2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1350, 0, 90, 100));

        vidaProtag.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        vidaProtag.setForeground(new java.awt.Color(255, 255, 255));
        vidaProtag.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        vidaProtag.setText("100");
        getContentPane().add(vidaProtag, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 0, 110, 100));

        vidaInimigo.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        vidaInimigo.setForeground(new java.awt.Color(255, 255, 255));
        vidaInimigo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        vidaInimigo.setText("100");
        getContentPane().add(vidaInimigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(1220, 0, 110, 100));

        protagonista.setText("jLabel2");
        getContentPane().add(protagonista, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, 260, 510));

        Coracao.setText("jLabel1");
        getContentPane().add(Coracao, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 90, 100));

        fundoProtagonista.setText("jLabel1");
        getContentPane().add(fundoProtagonista, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1440, 750));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void alternativaAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alternativaAActionPerformed
        Questoes perguntas = new Questoes();
        switch (Fases.perguntaCont) {
            case 1:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 2:
                Player.acertosJogo ++;
                if (Fases.timer.isRunning()) {
                    Fases.timer.stop();
                }
                int pontos = Fases.calcularPontos(Fases.tempoDecorrido);
                Player.pontosJogo += pontos;
                Inimigos.inimigos(this);
                break;
            case 3:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 4:
                 Player.errosJogo ++;
                 Player.vidaJogo -= 50;
                if (Player.vidaJogo == 0){
                   Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
               Inimigos.inimigos(this);
                }
               break;
            case 5:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 6:
                Player.vidaJogo -= 50;
                Player.errosJogo ++;
                if (Player.vidaJogo == 0){
                    Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                    SafeRoom.saladeSave(this);
                }
                break;
            case 7:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
           case 8:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaInimigo, questao, a, b, c, d);
                break;
            case 9:
                if (Fases.timer.isRunning()) {
                    Fases.timer.stop();
                }
               pontos = Fases.calcularPontos(Fases.tempoDecorrido);
               Player.pontosJogo += pontos;
               Inimigos.inimigos(this);
               Player.acertosJogo ++;
               break;
            case 10:
               perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 11:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 12:
                if (Fases.timer.isRunning()) {
                    Fases.timer.stop();
                }
                pontos = Fases.calcularPontos(Fases.tempoDecorrido);
                Player.pontosJogo += pontos;
               Inimigos.inimigos(this);
               Player.acertosJogo ++;
               break;
            case 13:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                break;
            case 14:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 15:
                Player.vidaJogo -= 50;
                Player.errosJogo ++;
                if (Player.vidaJogo == 0){
                    Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                    SafeRoom.saladeSave(this);
                }
                break;
            case 16:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 17:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 18:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 19:
                if (Fases.timer.isRunning()) {
                    Fases.timer.stop();
                }
                pontos = Fases.calcularPontos(Fases.tempoDecorrido);
                Player.pontosJogo += pontos;
                Inimigos.inimigos(this);
                Player.acertosJogo ++;
                break;
            case 20:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 21:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 22:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 23:
                Player.vidaJogo -= 34;
                Player.errosJogo ++;
                if (Player.vidaJogo == 0){
                   Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                Inimigos.inimigos(this);
                }
                break;
            case 24:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                break;
            case 25:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 26:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 27:
                Player.vidaJogo -= 34;
                Player.errosJogo ++;
                if (Player.vidaJogo == 0){
                    Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                    SafeRoom.saladeSave(this);
                }
                break;
            case 28:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                break;
            case 29:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 30:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 31:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 32:
                Player.vidaJogo -= 34;
                Player.errosJogo ++;
                Player jogador = new Player();
                jogador.setUsername(Player.nome);
                jogador.setVida(Player.vidaJogo);
                jogador.setAcertos(Player.acertosJogo);
                jogador.setErros(Player.errosJogo);
                jogador.setPontos(Player.pontosJogo);
                jogador.inserir();
                Inimigos.inimigos(this);
                break;
        }
    }//GEN-LAST:event_alternativaAActionPerformed

    private void alternativaBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alternativaBActionPerformed
        Questoes perguntas = new Questoes();
        switch (Fases.perguntaCont) {
            case 1:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 2:
                Player.vidaJogo -= 50;
                Player.errosJogo ++;
                if (Player.vidaJogo == 0){
                   Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                Inimigos.inimigos(this);
                }
                break;
            case 3:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                break;
            case 4:
                Player.vidaJogo -= 50;
                Player.errosJogo ++;
                if (Player.vidaJogo == 0){
                   Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
               Inimigos.inimigos(this);
                }
               break;
            case 5:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break; 
            case 6:
                Player.vidaJogo -= 50;
                Player.errosJogo ++;
                if (Player.vidaJogo == 0){
                    Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                    SafeRoom.saladeSave(this);
                }
                break;
            case 7:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                
                break;
            case 8:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                
                break;
            case 9:
               Player.vidaJogo -= 50;
               Player.errosJogo ++;
               if (Player.vidaJogo == 0){
                   Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
               Inimigos.inimigos(this);
               }
               break;
            case 10:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
           case 11:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                break;
            case 12:
               Player.vidaJogo -= 50;
               Player.errosJogo ++;
               if (Player.vidaJogo == 0){
                   Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
               Inimigos.inimigos(this);
               }
               break;
            case 13:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 14:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 15:
                Player.vidaJogo -= 50;
                Player.errosJogo ++;
                if (Player.vidaJogo == 0){
                    Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                    SafeRoom.saladeSave(this);
                }
                break;
            case 16:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                break;
            case 17:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                break;
            case 18:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 19:
                Player.vidaJogo -= 34;
               Player.errosJogo ++;
               if (Player.vidaJogo == 0){
                   Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                Inimigos.inimigos(this);
               }
                break;
            case 20:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 21:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                break;
            case 22:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 23:
                Player.vidaJogo -= 34;
               Player.errosJogo ++;
               if (Player.vidaJogo == 0){
                   Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                Inimigos.inimigos(this);
               }
                break;
            case 24:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 25:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                break;
            case 26:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 27:
                Player.vidaJogo -= 34;
                Player.errosJogo ++;
                if (Player.vidaJogo == 0){
                    Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                    SafeRoom.saladeSave(this);
                }
                break;
            case 28:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 29:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                break;
            case 30:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 31:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                break;
            case 32:
                Player.vidaJogo -= 34;
                Player.errosJogo ++;
                Player jogador = new Player();
                jogador.setUsername(Player.nome);
                jogador.setVida(Player.vidaJogo);
                jogador.setAcertos(Player.acertosJogo);
                jogador.setErros(Player.errosJogo);
                jogador.setPontos(Player.pontosJogo);
                jogador.inserir();
                Inimigos.inimigos(this);
                break;
        }
    }//GEN-LAST:event_alternativaBActionPerformed

    private void alternativaDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alternativaDActionPerformed
       Questoes perguntas = new Questoes();
        switch (Fases.perguntaCont){
            case 1:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);;
                break;
            case 2:
               Player.vidaJogo -= 50;
               Player.errosJogo ++;
               if (Player.vidaJogo == 0){
                   Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
               Inimigos.inimigos(this);
               }
               break;
            case 3:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 4:
                if (Fases.timer.isRunning()) {
                    Fases.timer.stop();
                }
                int pontos = Fases.calcularPontos(Fases.tempoDecorrido);
                Player.pontosJogo += pontos;
                Inimigos.inimigos(this);
               Player.acertosJogo ++;
               break;
            case 5:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break; 
            case 6:
                Player.vidaJogo -= 50;
                Player.errosJogo ++;
                if (Player.vidaJogo == 0){
                    Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                    SafeRoom.saladeSave(this);
                }
                break;
            case 7:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                
                break;
            case 8:
               perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                
                break;
            case 9:
               Player.vidaJogo -= 50;
               Player.errosJogo ++;
               if (Player.vidaJogo == 0){
                   Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
               Inimigos.inimigos(this);
               }
               break;
            case 10:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 11:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 12:
               Player.vidaJogo -= 50;
               Player.errosJogo ++;
               if (Player.vidaJogo == 0){
                   Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
               Inimigos.inimigos(this);
               }
               break;
            case 13:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 14:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                break;
            case 15:
                Player.vidaJogo -= 50;
                Player.errosJogo ++;
                if (Player.vidaJogo == 0){
                    Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                    SafeRoom.saladeSave(this);
                }
                break;
            case 16:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 17:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 18:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 19:
                Player.vidaJogo -= 34;
               Player.errosJogo ++;
               if (Player.vidaJogo == 0){
                   Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                Inimigos.inimigos(this);
               }
                break;
            case 20:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                break;
            case 21:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 22:
                perguntas.proximaQuestao();
                Inimigos.vidaInimigo -= 25;
                Fases.perguntaCont ++;
                vidaInimigo.setText(Integer.toString(Inimigos.vidaInimigo));
                questao.setText(Fases.questao );
                a.setText(Fases.alternativa1 );
                b.setText(Fases.alternativa2 );
                c.setText(Fases.alternativa3 );
                d.setText(Fases.alternativa4 );
                Player.acertosJogo ++;
                Player.pontosJogo += 100;
                break;
            case 23:
                if (Fases.timer.isRunning()) {
                    Fases.timer.stop();
                }
                pontos = Fases.calcularPontos(Fases.tempoDecorrido);
                Player.pontosJogo += pontos;
                Inimigos.inimigos(this);
                Player.acertosJogo ++;
                break;
            case 24:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 25:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 26:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                break;
            case 27:
                Player.vidaJogo -= 34;
                Player.errosJogo ++;
                if (Player.vidaJogo == 0){
                    Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                    SafeRoom.saladeSave(this);
                }
                break;
            case 28:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 29:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 30:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 31:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 32:
                Player.acertosJogo ++;
                if (Fases.timer.isRunning()) {
                    Fases.timer.stop();
                }
                pontos = Fases.calcularPontos(Fases.tempoDecorrido);
                Player.pontosJogo += pontos;
                Player jogador = new Player();
                jogador.setUsername(Player.nome);
                jogador.setVida(Player.vidaJogo);
                jogador.setAcertos(Player.acertosJogo);
                jogador.setErros(Player.errosJogo);
                jogador.setPontos(Player.pontosJogo);
                jogador.inserir();
                Inimigos.inimigos(this);
                break;
       }
    }//GEN-LAST:event_alternativaDActionPerformed

    private void alternativaCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alternativaCActionPerformed
        Questoes perguntas = new Questoes();
        switch (Fases.perguntaCont) {
            case 1:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 2:
                Player.vidaJogo -= 50;
               Player.errosJogo ++;
               if (Player.vidaJogo == 0){
                   Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                Inimigos.inimigos(this);
               }
                break;
            case 3:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 4:
               Inimigos.inimigos(this);
               Player.acertosJogo ++;
               Player.pontosJogo += 100;
               break;
            case 5:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                break; 
            case 6:
                Player.acertosJogo ++;
                if (Fases.timer.isRunning()) {
                    Fases.timer.stop();
                }
                int pontos = Fases.calcularPontos(Fases.tempoDecorrido);
                Player.pontosJogo += pontos;
                if (Player.vidaJogo == 0){
                    Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                    SafeRoom.saladeSave(this);
                }
                break;
            case 7:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                
                break;
            case 8:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                
                break;
            case 9:
               Player.vidaJogo -= 50;
               Player.errosJogo ++;
               if (Player.vidaJogo == 0){
                   Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
               Inimigos.inimigos(this);
               }
               break;
            case 10:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                break;
            case 11:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 12:
               Player.vidaJogo -= 50;
               Player.errosJogo ++;
               if (Player.vidaJogo == 0){
                   Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
               Inimigos.inimigos(this);
               }
               break;
            case 13:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 14:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 15:
                Player.acertosJogo ++;
                if (Fases.timer.isRunning()) {
                    Fases.timer.stop();
                }
                pontos = Fases.calcularPontos(Fases.tempoDecorrido);
                Player.pontosJogo += pontos;
                if (Player.vidaJogo == 0){
                    Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                    SafeRoom.saladeSave(this);
                }
                break;
            case 16:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 17:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 18:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                break;
            case 19:
                Player.vidaJogo -= 34;
               Player.errosJogo ++;
               if (Player.vidaJogo == 0){
                   Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                Inimigos.inimigos(this);
               }
                break;
            case 20:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 21:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 22:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 23:
               Player.vidaJogo -= 34;
               Player.errosJogo ++;
               if (Player.vidaJogo == 0){
                   Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                Inimigos.inimigos(this);
               }
                break;
            case 24:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 25:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 26:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 27:
                Player.acertosJogo ++;
                if (Fases.timer.isRunning()) {
                    Fases.timer.stop();
                }
                pontos = Fases.calcularPontos(Fases.tempoDecorrido);
                Player.pontosJogo += pontos;
                if (Player.vidaJogo == 0){
                    Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                }
                else{
                    SafeRoom.saladeSave(this);
                }
                break;
            case 28:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 29:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 30:
                perguntas.proximaQuestao();
                Fases.acertar(this, vidaInimigo, questao, a, b, c, d);
                break;
            case 31:
                perguntas.proximaQuestao();
                Fases.errar(this, vidaProtag, questao, a, b,c ,d);
                break;
            case 32:
                Player.vidaJogo -= 34;
                Player.errosJogo ++;
                Player jogador = new Player();
                jogador.setUsername(Player.nome);
                jogador.setVida(Player.vidaJogo);
                jogador.setAcertos(Player.acertosJogo);
                jogador.setErros(Player.errosJogo);
                jogador.setPontos(Player.pontosJogo);
                jogador.inserir();
               Inimigos.inimigos(this);
                break;
        }
    }//GEN-LAST:event_alternativaCActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaQuiz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaQuiz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaQuiz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaQuiz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaQuiz().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AracnaX;
    private javax.swing.JLabel BloodReaper;
    private javax.swing.JLabel Coracao;
    private javax.swing.JLabel Coracao2;
    private javax.swing.JLabel JackOBird;
    private javax.swing.JLabel Magnata;
    private javax.swing.JLabel MetaVurpura;
    private javax.swing.JLabel Notivaga;
    private javax.swing.JLabel Oblivion;
    private javax.swing.JLabel PanteraLotus;
    private javax.swing.JLabel Ruptura;
    private javax.swing.JLabel Visage;
    private javax.swing.JTextArea a;
    private javax.swing.JRadioButton alternativaA;
    private javax.swing.JRadioButton alternativaB;
    private javax.swing.JRadioButton alternativaC;
    private javax.swing.JRadioButton alternativaD;
    private javax.swing.JTextArea b;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextArea c;
    private javax.swing.JTextArea d;
    private javax.swing.JLabel fundo;
    private javax.swing.JLabel fundoProtagonista;
    private javax.swing.JLabel nomeAranha;
    private javax.swing.JLabel nomeCobra;
    private javax.swing.JLabel nomeCultista;
    private javax.swing.JLabel nomeDruida;
    private javax.swing.JLabel nomeEntidade;
    private javax.swing.JLabel nomeEspirito;
    private javax.swing.JLabel nomeFantasma;
    private javax.swing.JLabel nomePantera;
    private javax.swing.JLabel nomeProtag;
    private javax.swing.JLabel nomeTerrorBird;
    private javax.swing.JLabel nomeVilao;
    private javax.swing.JLabel protagonista;
    private javax.swing.JLabel questao;
    private javax.swing.JLabel vidaInimigo;
    private javax.swing.JLabel vidaProtag;
    // End of variables declaration//GEN-END:variables
}
