import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class Fases {
    public static int tempoTotal = 180000;
    public static int tempoDecorrido = 0;
    public static Timer timer;
    static String inimigo;
    static String nomeInimigo;
    static String questao;
    static String alternativa1;
    static String alternativa2;
    static String alternativa3;
    static String alternativa4;
    static  int faseCont;
    static int perguntaCont;
    public static void errar(JFrame tela,JLabel vida, JLabel pergunta, JTextArea a,JTextArea b, JTextArea c, JTextArea d){
        if (Fases.timer.isRunning()) {
                    Fases.timer.stop();
                }
        if (Fases.faseCont >= 1 && Fases.faseCont <= 6){
            Player.vidaJogo -=  50;
        }
        else if (Fases.faseCont >= 7 && Fases.faseCont <= 10){
            Player.vidaJogo -=  34;
        }
        if (Player.vidaJogo <= 0){
            Audios.stopBackgroundMusic();
            Audios.playBackgroundMusic(TelaInicial.sonsDire +"\\Vazio.wav");
            Audios.playSound(TelaInicial.sonsDire + "\\Morte.wav");
            GameOver perdeu = new GameOver();
            perdeu.setVisible(true);
            tela.dispose();
        }
        else{
            Fases.perguntaCont ++;
            vida.setText(Integer.toString(Player.vidaJogo));
            pergunta.setText(Fases.questao );
            a.setText(Fases.alternativa1 );
            b.setText(Fases.alternativa2 );
            c.setText(Fases.alternativa3 );
            d.setText(Fases.alternativa4 );
        }
        Player.errosJogo ++;
    }
   public static void acertar(JFrame tela, JLabel vida, JLabel pergunta, JTextArea a, JTextArea b, JTextArea c, JTextArea d) {
       if (Fases.timer.isRunning()) {
                    Fases.timer.stop();
                }
        int tempoDecorrido = Fases.tempoDecorrido;
        int pontos = calcularPontos(tempoDecorrido);

        if (Fases.faseCont >= 1 && Fases.faseCont <= 3) {
            Inimigos.vidaInimigo -= 50;
        } else if (Fases.faseCont >= 4 && Fases.faseCont <= 6) {
            Inimigos.vidaInimigo -= 34;
        } else if (Fases.faseCont >= 7 && Fases.faseCont <= 9) {
            Inimigos.vidaInimigo -= 25;
        } else {
            Inimigos.vidaInimigo -= 20;
        }

        if (Inimigos.vidaInimigo <= 0) {
            colocarQuestoes(tela, vida, pergunta, a, b, c, d);
        } else {
            Fases.perguntaCont++;
            colocarQuestoes(tela, vida, pergunta, a, b, c, d);
        }

        Player.acertosJogo++;
        Player.pontosJogo += pontos;
        Fases.tempoDecorrido = 0;
    }
    public static void colocarQuestoes(JFrame tela, JLabel vida, JLabel pergunta, JTextArea a, JTextArea b, JTextArea c, JTextArea d) {
        vida.setText(Integer.toString(Inimigos.vidaInimigo));
        pergunta.setText(Fases.questao);
        a.setText(Fases.alternativa1);
        b.setText(Fases.alternativa2);
        c.setText(Fases.alternativa3);
        d.setText(Fases.alternativa4);
        iniciarTimer();
    }
    public static int calcularPontos(int tempoDecorrido) {
        int points;
        if (tempoDecorrido <= 5000) {
            points = 1000;
        } else if (tempoDecorrido <= 120000 && tempoDecorrido > 5000) {
            points = 500;
        } else if (tempoDecorrido <= 300000 && tempoDecorrido > 120000) {
            points = 200;
        } else if (tempoDecorrido <= 600000 && tempoDecorrido > 300000) {
            points = 100;
        } else {
            points = 50;
        }
        return points;
    }
    public static void iniciarTimer() {
        timer = new Timer(5000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tempoDecorrido += 1000;
                if (tempoDecorrido >= tempoTotal) {
                    timer.stop();
                } else {
                }
            }
        });
        timer.start();
    }
}
