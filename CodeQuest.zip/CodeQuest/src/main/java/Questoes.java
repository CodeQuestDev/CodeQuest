
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Questoes {
    public String proximaQuestao(){
        String sql = "SELECT enunciado, alternativa1, alternativa2, alternativa3, alternativa4 FROM questoes where idquestao = ?";
        String s = "";
        ConexaoDB factory = new ConexaoDB();
        try (Connection conexao = factory.obtemConexao()){
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setInt(1, Fases.perguntaCont);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Fases.questao = rs.getString("enunciado");
                Fases.alternativa1 = rs.getString("alternativa1");
                Fases.alternativa2 = rs.getString("alternativa2");
                Fases.alternativa3 = rs.getString("alternativa3");
                Fases.alternativa4 = rs.getString("alternativa4");
            } else {
                s += "Nenhuma questão encontrada.";
            }
            }
        catch(Exception e){
            s += "Registros não encontrados.";
            e.printStackTrace();
        }
        return s;
}
}