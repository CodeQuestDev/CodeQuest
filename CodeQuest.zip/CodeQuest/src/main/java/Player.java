import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Player {
    static String nome;
    static int vidaJogo;
    static int acertosJogo = 0;
    static int errosJogo = 0;
    static int pontosJogo = 0;
    private String username;
    private int vida;
    private int acertos;
    private int erros;
    private int pontos;
    private int id;
    public Player() {
    }

    public Player(String username, int vida, int acertos, int erros, int pontos, int id) {
        this.username = username;
        this.vida = vida;
        this.acertos = acertos;
        this.erros = erros;
        this.pontos = pontos;
        this.id = id;
    }

    public static String getNome() {
        return nome;
    }

    public static void setNome(String nome) {
        Player.nome = nome;
    }

    public static int getVidaJogo() {
        return vidaJogo;
    }

    public static void setVidaJogo(int vidaJogo) {
        Player.vidaJogo = vidaJogo;
    }

    public static int getAcertosJogo() {
        return acertosJogo;
    }

    public static void setAcertosJogo(int acertosJogo) {
        Player.acertosJogo = acertosJogo;
    }

    public static int getErrosJogo() {
        return errosJogo;
    }

    public static void setErrosJogo(int errosJogo) {
        Player.errosJogo = errosJogo;
    }

    public static int getPontosJogo() {
        return pontosJogo;
    }

    public static void setPontosJogo(int pontosJogo) {
        Player.pontosJogo = pontosJogo;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public int getAcertos() {
        return acertos;
    }

    public void setAcertos(int acertos) {
        this.acertos = acertos;
    }

    public int getErros() {
        return erros;
    }

    public void setErros(int erros) {
        this.erros = erros;
    }
    public int getPontos() {
        return pontos;
    }

    public void setPontos(int pontos) {
        this.pontos = pontos;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

   
    public void inserir(){
        String sql = "insert into player (nome, vida, acertos, erros, pontos) values (?, ?, ?, ?, ?)";
        ConexaoDB factory = new ConexaoDB();
        try (Connection conexao = factory.obtemConexao()){
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setString(1, username);
            ps.setInt (2, vida);
            ps.setInt (3, acertos);
            ps.setInt (4, erros);
            ps.setInt (5, pontos);
            ps.execute();
        }
        catch(Exception e){
            e.printStackTrace(); 
        }
    }
    public String listar(JTable tabela){
        String sql = "SELECT idPlayer, nome, pontos FROM player order by pontos desc limit 10;";
        int colocacao = 1;
        ConexaoDB factory = new ConexaoDB();
        String s = "";
        try (Connection conexao = factory.obtemConexao()){
            PreparedStatement ps = conexao.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()){
                int id = rs.getInt("idPlayer");
                String nome = rs.getString("nome");
                int pontos = rs.getInt("pontos");
                DefaultTableModel model = (DefaultTableModel) tabela.getModel();
                model.addRow(new Object[]{colocacao, id, nome, pontos});
                colocacao ++;
            }
        }
        
        catch(Exception e){
            s += "Registros não encontrados.";
            e.printStackTrace();
        }
        return s;
    }
    public String posicao(JTable tabela){
        String sql = "SELECT idPlayer, nome, pontos, acertos, erros, vida FROM player order by pontos desc;";
        int colocacao = 1;
        ConexaoDB factory = new ConexaoDB();
        String s = "";
        try (Connection conexao = factory.obtemConexao()){
            PreparedStatement ps = conexao.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()){
                id = rs.getInt("idPlayer");
                username = rs.getString("nome");
                acertos = rs.getInt("acertos");
                vida = rs.getInt("vida");
                erros = rs.getInt("erros");
                pontos = rs.getInt("pontos");
                colocacao ++;
                if (nome.equals(username) && pontosJogo == pontos && acertosJogo == acertos && errosJogo == erros && vidaJogo == vida){
                    DefaultTableModel model = (DefaultTableModel) tabela.getModel();
                    model.addRow(new Object[]{colocacao, id, username, pontos});
                }
            }
        }
        
        catch(Exception e){
            s += "Registros não encontrados.";
            e.printStackTrace();
        }
        return s;
    }
}
