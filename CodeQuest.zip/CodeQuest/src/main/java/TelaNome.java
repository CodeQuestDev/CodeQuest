import javax.swing.*;
public class TelaNome extends javax.swing.JFrame {
public TelaNome() {
        super("CodeQuest");
        initComponents();
        this.setLocationRelativeTo(null);
        TelaInicial.scaleImage(TelaInicial.backgroundDire + "\\mesa.png", loginBackground);
        TelaInicial.scaleImage(TelaInicial.backgroundDire + "\\papiro.png", loginBackground2);
        TelaInicial.scaleImage(TelaInicial.personagemDire +"\\protagonista.png", personagemLogin);
        //TelaInicial.scaleImageButton(TelaInicial.interfaceDire +"\\login.png", enterUsername);
       // TelaInicial.scaleImageButton(TelaInicial.interfaceDire +"\\voltar.png", cancelButton);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        loginTitulo = new javax.swing.JLabel();
        personagemLogin = new javax.swing.JLabel();
        loginTextField = new javax.swing.JTextField();
        cancelButton = new javax.swing.JButton();
        enterUsername = new javax.swing.JButton();
        loginBackground2 = new javax.swing.JLabel();
        loginBackground = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        loginTitulo.setFont(new java.awt.Font("French Script MT", 2, 80)); // NOI18N
        loginTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loginTitulo.setText("Escreva o seu nome:");
        getContentPane().add(loginTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 140, 770, 110));

        personagemLogin.setText("jLabel1");
        getContentPane().add(personagemLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 231, 487));

        loginTextField.setBackground(new java.awt.Color(255, 255, 237));
        loginTextField.setFont(new java.awt.Font("French Script MT", 0, 70)); // NOI18N
        loginTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginTextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(loginTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(335, 288, 770, 110));

        cancelButton.setFont(new java.awt.Font("French Script MT", 0, 80)); // NOI18N
        cancelButton.setText("Voltar");
        cancelButton.setBorder(null);
        cancelButton.setBorderPainted(false);
        cancelButton.setContentAreaFilled(false);
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });
        getContentPane().add(cancelButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 430, 300, 200));

        enterUsername.setFont(new java.awt.Font("French Script MT", 0, 80)); // NOI18N
        enterUsername.setText("Login");
        enterUsername.setBorder(null);
        enterUsername.setBorderPainted(false);
        enterUsername.setContentAreaFilled(false);
        enterUsername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enterUsernameActionPerformed(evt);
            }
        });
        getContentPane().add(enterUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 430, 300, 200));

        loginBackground2.setText("jLabel1");
        getContentPane().add(loginBackground2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 10, 990, 670));

        loginBackground.setText("jLabel1");
        getContentPane().add(loginBackground, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1440, 750));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void loginTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginTextFieldActionPerformed
        
    }//GEN-LAST:event_loginTextFieldActionPerformed

    private void enterUsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enterUsernameActionPerformed
        Player.nome = loginTextField.getText();
        if ("".equals(Player.nome) || " ".equals(Player.nome)){
            Player.nome = "CrowMask";
        }
        Player.vidaJogo = 100;
        SafeRoom.save = 0;
        Inimigos.vidaInimigo = 100;
        Inimigos.inimigos(this);
    }//GEN-LAST:event_enterUsernameActionPerformed

    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
        Audios.stopBackgroundMusic();
        Audios.playBackgroundMusic(TelaInicial.sonsDire +"\\Vazio.wav");
        TelaInicial menu = new TelaInicial();
        menu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_cancelButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaNome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaNome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaNome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaNome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaNome().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancelButton;
    public static javax.swing.JButton enterUsername;
    private javax.swing.JLabel loginBackground;
    private javax.swing.JLabel loginBackground2;
    private javax.swing.JTextField loginTextField;
    private javax.swing.JLabel loginTitulo;
    private javax.swing.JLabel personagemLogin;
    // End of variables declaration//GEN-END:variables
}
