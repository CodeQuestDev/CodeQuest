// este codigo "ensina" o java a "falar" SQL
import java.sql.Connection;
import java.sql.DriverManager;
public class ConexaoDB {
    private static String host = "localhost";
    private static String porta = "3306";
    private static String db = "codequest";
    private static String usuario = "root";
    private static String senha = "23.01390-7";
    public static Connection obtemConexao () throws Exception {
        String url = String.format("jdbc:mysql://%s:%s/%s?useTimezone=true&serverTimezone=UTC",host,porta,db);
        return DriverManager.getConnection(url, usuario, senha);
    }
}