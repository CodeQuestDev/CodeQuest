// imports de imagem
import java.awt.Image;
import javax.swing.ImageIcon;
// cria a tela de ranking
public class Ranking extends javax.swing.JFrame {

    public Ranking() {
    super("CodeQuest");
    initComponents();
    this.setLocationRelativeTo(null);
    TelaInicial.scaleImage(TelaInicial.backgroundDire + "\\fundo.jpeg", Fundo);
    ImageIcon gifIcon = new ImageIcon(TelaInicial.interfaceDire + "\\creditos.gif");
    Image gifImage = gifIcon.getImage();
    int width = creditos.getWidth();
    int height = creditos.getHeight();
    Image resizedImage = gifImage.getScaledInstance(width, height, Image.SCALE_DEFAULT);
    ImageIcon resizedIcon = new ImageIcon(resizedImage);
    creditos.setIcon(resizedIcon);
    Player player = new Player();
    player.listar(tabela);
    tabela.setRowHeight(tabela.getRowHeight() + 21);
    player.posicao(colocacao);
    colocacao.setRowHeight(colocacao.getRowHeight() + 21);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        colocacao = new javax.swing.JTable();
        Pular = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        creditos = new javax.swing.JLabel();
        Titulo1 = new javax.swing.JLabel();
        Titulo = new javax.swing.JLabel();
        Fundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(1440, 750));
        setMinimumSize(new java.awt.Dimension(1440, 750));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        colocacao.setAutoCreateRowSorter(true);
        colocacao.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        colocacao.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Colocação", "ID", "Nome", "Pontuação"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        colocacao.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        jScrollPane2.setViewportView(colocacao);
        if (colocacao.getColumnModel().getColumnCount() > 0) {
            colocacao.getColumnModel().getColumn(0).setMinWidth(70);
            colocacao.getColumnModel().getColumn(0).setPreferredWidth(70);
            colocacao.getColumnModel().getColumn(0).setMaxWidth(70);
            colocacao.getColumnModel().getColumn(1).setMinWidth(50);
            colocacao.getColumnModel().getColumn(1).setPreferredWidth(50);
            colocacao.getColumnModel().getColumn(1).setMaxWidth(50);
            colocacao.getColumnModel().getColumn(2).setMinWidth(150);
            colocacao.getColumnModel().getColumn(2).setPreferredWidth(150);
            colocacao.getColumnModel().getColumn(2).setMaxWidth(150);
        }

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 630, 450, 70));

        Pular.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        Pular.setForeground(new java.awt.Color(255, 255, 255));
        Pular.setText("Pular");
        Pular.setBorder(null);
        Pular.setBorderPainted(false);
        Pular.setContentAreaFilled(false);
        Pular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PularActionPerformed(evt);
            }
        });
        getContentPane().add(Pular, new org.netbeans.lib.awtextra.AbsoluteConstraints(1220, 660, 220, 90));

        tabela.setAutoCreateRowSorter(true);
        tabela.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Colocação", "ID", "Nome", "Pontuação"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabela.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        jScrollPane1.setViewportView(tabela);
        if (tabela.getColumnModel().getColumnCount() > 0) {
            tabela.getColumnModel().getColumn(0).setMinWidth(70);
            tabela.getColumnModel().getColumn(0).setPreferredWidth(70);
            tabela.getColumnModel().getColumn(0).setMaxWidth(70);
            tabela.getColumnModel().getColumn(1).setMinWidth(50);
            tabela.getColumnModel().getColumn(1).setPreferredWidth(50);
            tabela.getColumnModel().getColumn(1).setMaxWidth(50);
            tabela.getColumnModel().getColumn(2).setMinWidth(150);
            tabela.getColumnModel().getColumn(2).setPreferredWidth(150);
            tabela.getColumnModel().getColumn(2).setMaxWidth(150);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 69, -1, 400));
        getContentPane().add(creditos, new org.netbeans.lib.awtextra.AbsoluteConstraints(452, 0, 990, 750));

        Titulo1.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        Titulo1.setForeground(new java.awt.Color(255, 255, 255));
        Titulo1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Titulo1.setText("Sua posição");
        getContentPane().add(Titulo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 510, 450, 69));

        Titulo.setFont(new java.awt.Font("Arial", 0, 48)); // NOI18N
        Titulo.setForeground(new java.awt.Color(255, 255, 255));
        Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Titulo.setText("Ranking ");
        getContentPane().add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 450, 69));

        Fundo.setText("jLabel1");
        getContentPane().add(Fundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 450, 750));

        pack();
    }// </editor-fold>//GEN-END:initComponents
// reseta o jogo ( botao pular- creditos)
    private void PularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PularActionPerformed
        Audios.stopBackgroundMusic();
        Audios.playBackgroundMusic(TelaInicial.sonsDire +"\\Vazio.wav");
        TelaInicial restart = new TelaInicial();
        restart.setVisible(true);
        Fases.perguntaCont = 0;
        Fases.faseCont = 0;
        Player.acertosJogo = 0;
        Player.errosJogo = 0;
        Player.pontosJogo = 0;
        this.dispose();
    }//GEN-LAST:event_PularActionPerformed
// netbeans
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ranking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ranking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ranking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ranking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ranking().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Fundo;
    private javax.swing.JButton Pular;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel Titulo1;
    private javax.swing.JTable colocacao;
    private javax.swing.JLabel creditos;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tabela;
    // End of variables declaration//GEN-END:variables
}
